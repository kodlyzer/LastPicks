# Changelog

## 0.4.0

* Added exactly() mixin

## 0.3.0

* Added more checks

## 0.2.0

* Small fixes

## 0.1.0

* Initial release
