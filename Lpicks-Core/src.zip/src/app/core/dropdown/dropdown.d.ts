interface Dropdown {
    title: string;
    items: DropdownItem[];
}

interface DropdownItem {
    link: string;
    name: string;
    sub?: []
}
