import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'kdi-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent implements OnInit {
  open = false;
  @Input() dropdown: Dropdown;

  constructor() {
  }

  ngOnInit() {
  }

  close() {
    this.open = false;
  }
}
