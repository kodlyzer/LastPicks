import { NgModule } from '@angular/core';
import { DropdownDemoComponent } from './dropdown-demo/dropdown-demo.component';
import { CoreModule } from '../core/core.module';

@NgModule({
    imports: [CoreModule],
    declarations: [DropdownDemoComponent],
    exports: [DropdownDemoComponent]
})
export class DemoModule { }
